/* I am Rachit Jain. This project includes the analysis of an array of unsigned char dataitems. 
The analysis includes finding the maximum, minimum, mean and median of the array and then print the statistics 
and the sorted array on the console.*/
